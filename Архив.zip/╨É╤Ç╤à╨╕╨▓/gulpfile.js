var gulp        = require('gulp');
var browserSync = require('browser-sync');
// webserver
gulp.task('default', function() {
    browserSync({
        proxy: 'https://dev.nonstopbonus.com',
        files: ['./files/css/*.css', './files/js/*.js'],
        middleware: require('serve-static')('./'),
        rewriteRules: [
            {
                match: new RegExp('files/css/main_new.css'),
                fn: function() {
                    return 'files/css/main.css'
                }
            },
            {
                match: new RegExp('files/JS/combine12_new.js'),
                fn: function() {
                    return 'files/js/combine12.js'
                }
            },
            {
                match: new RegExp('files/css/reviews_new.css'),
                fn: function() {
                    return 'files/css/reviews.css'
                }
            },
            {
                match: new RegExp('files/img/icon-001.png'),
                fn: function() {
                    return 'files/img/eye.svg'
                }
            },
            {
                match: new RegExp('files/img/icon-002.png'),
                fn: function() {
                    return 'files/img/account.svg'
                }
            },
            {
                match: new RegExp('files/img/icon-003.png'),
                fn: function() {
                    return 'files/img/comment.svg'
                }
            },
            {
                match: new RegExp('files/img/icon-004.png'),
                fn: function() {
                    return 'files/img/thumb-up.svg'
                }
            },
            {
                match: new RegExp('files/img/icon-005.png'),
                fn: function() {
                    return 'files/img/thumb-down.svg'
                }
            },
        ],
        port: 8080,
        https: true,
        open: true
    });
});
